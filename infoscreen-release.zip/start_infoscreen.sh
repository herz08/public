#!/bin/sh

# Virtuelle Umgebung aktivieren
source infoscreen/bin/activate

# Python-Datei ausführen
python3 infoscreen.py

# Virtuelle Umgebung deaktivieren (optional)
deactivate
